/*
J.D.Protiva
CS360 Spring2018
Assignment: 1
Programe Discription:
This is the Connect Four Board class that has operations to help play a game of connect four.
Boar was alread initalized in the .h file. 

*/
#include <iostream>
#include "ConnectFourBoard.h"
using namespace std;

/*
ConnectFourBoard is the constructor for ConnectFourBoard class.It sets all valse of Board to '_'.

Parameters:
Board- already established in .h is used to set values.

Return: n/a
*/
ConnectFourBoard::ConnectFourBoard(){
	
	//nested for loop to tryvers hole array
	for(int i=0 ; i <6;i++)
	{
		for(int j =0; j<7; j++)
		{
			//sets array to '_'
			Board[i][j]= '_';
		}
	}

}

/*
showBoard is a method that prints the board in the termanel. 

Parameters:
Board- is called for the print statments.

Return: nune
*/
void ConnectFourBoard::showBoard()
{
cout << "ConnectFourBoard\n0 1 2 3 4 5 6" << endl;
//nested for to navigate hole array
for(int i=0 ; i <6;i++)
	{
		for(int j =0; j<7; j++)
		{
			//print wats stared in board 
			cout<< Board[i][j]<<" ";
		}
			cout << endl;	
	}
}

/*
reset is a method that resets the board.

Parameters:
Board- is used to reset the board 

Return: nune
*/
void ConnectFourBoard::reset(){

	//nested for loot to navigat hole array
	for(int i=0 ; i <6;i++)
	{
		for(int j =0; j<7; j++)
		{
			//resets board to '_'
			Board[i][j]= '_';
		}
	}
}
/*
Drop is a method that is passed a collem and turn and if the collem is not full puts the turns coller into that collem
if the collem is full it prompts the user to enter a diffrent collem.

Parameters:
collem- the colum of the board the person wants to play his peace.
turn- the coller the person is playing as.
worked - a boolean to determin when to leave while loop. 
Board- used to add the turn coller to the position of collem if availeble.

Return: nune
*/
void ConnectFourBoard::drop(int collem,char turn){
	bool worked = false;
	int j = 0;
	
	
	while (worked != true)
	{	
		if(cin.fail() || collem > 6 || collem < 0)
		{
			cin.clear(); 
			cin.ignore();
			cout<< "that row dose not exist please try again" << endl;
			cin >> collem;
		}
		else
		{
			//stopes once somthing is in collem or one past bottom of collem
			while( j <6 && Board[j][collem] == '_')
			{
				j = j+1;
			}
	
			j=j-1;

	
			//if collem is full
			if(j == -1)
			{
				cout<< "that row is full please try diffren row" << endl;
				cin >> collem;
				j=0;
			}
	
			//insrt 
			else
			{
				worked = true;
				Board[j][collem]=turn;
			}
		}
		
	}
}

/*

This method checks the vertical win condition, only the chips bellow the top chip of the passed collem.


Parameters:
win- set to true if they have won verticaly
collem- which collem im checking
wincoller- the coller at tomp on that collem

Return:
bool true if the win condition is met
*/
bool ConnectFourBoard::winvert (int collem){
	bool win = false;
	
	int j =0;
	while( j <5 && Board[j][collem] == '_')
	{
		
		j = j+1;
	}
	//j is first non '_' in collem
	char wincoller = Board[j][collem];
	if(j<=2)
	{
		//checks three spaces bellow j if they match j's coller
		if(Board[j+1][collem]==wincoller && Board[j+2][collem]==wincoller && Board[j+3][collem]==wincoller)
		{
		
			win = true;
		}
	}
	return win;
}

/*
winHorzont is a method that check if the horzontal win condition is met. 

Parameters:
collem-int to determen what im looking four. 
win-bool true once they have won also what is returned.
wincoller-char to determan the coller we are checking for.
numInRow-to count howmany wincollers are in a row.

Return:
boolean false if they have not won true if they have.
*/
bool ConnectFourBoard::winHorzont (int collem){
	bool win = false;
	int j =0;
	while( j <5 && Board[j][collem] == '_')
	{
		
		j = j+1;
	}
	
	char wincoller = Board[j][collem];
	int numInRow=1;
	
	//adding to numInRow for all in row to the right.
	if(collem != 7 && Board[j][collem+1]==wincoller){
		numInRow++;
		if(collem != 6 && Board[j][collem+2]==wincoller){
			numInRow++;
			if(collem != 5 && Board[j][collem+3]==wincoller){
				numInRow++;
				
			}
		}
	}
	//adding to numInRow for all in row to the left.
	if(collem != 0 && Board[j][collem-1]==wincoller){
		numInRow++;
		if(collem != 1 && Board[j][collem-2]==wincoller){
			numInRow++;
			if(collem != 2 && Board[j][collem-3]==wincoller){
				numInRow++;
			}
		}
	}
	
	if(numInRow >= 4){
		
		win = true;
	}
	return win;
}

/*
winNegSlope is a method the checks the diagnal win condition. If the row was a gragh it would have a negative slope. 

Parameters:
collem-to determin position we are checking.
win- return type true if they have won.
wincoller- coller of type we are conparing to. 
numInRow- a counter for how many are in row.

Return:
bool true if they have won false is they have not.

*/

bool ConnectFourBoard::winNegSlope (int collem){
	bool win = false;
	int j =0;
	while( j <5 && Board[j][collem] == '_')
	{
		
		j = j+1;
	}
	
	char wincoller = Board[j][collem];
	int numInRow=1;
	//to add to numinrow for down to right
	if(collem != 6 && j !=5 && Board[j+1][collem+1]==wincoller){
		numInRow++;
		if(collem != 5 && j !=4 && Board[j+2][collem+2]==wincoller){
			numInRow++;
			if(collem != 4 && j !=3 && Board[j+3][collem+3]==wincoller){
				numInRow++;
			}
		}
	}
	//add to numinrow for all up to left
	if(collem != 0 && j !=0 && Board[j-1][collem-1]==wincoller){
		numInRow++;
		if(collem != 1 && j !=1 && Board[j-2][collem-2]==wincoller){
			numInRow++;
			if(collem != 2 && j !=2 && Board[j-3][collem-3]==wincoller){
				numInRow++;
			}
		}
	}
	
	//cout <<"numInRow: " << numInRow << endl;
	if(numInRow >=4){

		win = true;
	}
	//cout <<"winNegSlope: " << win << endl;
	return win;
}

/*
winPossSlope checks the win condition if the four are in a row in a posidive slope 

Parameters:
collem-int column to check if it has created this win conndition
win- bool to return if won or not
wincoller-char to determin win coller
numInRow-int to count how many are in row

Return:
bool false if the didnt win ture if they did.
*/


bool ConnectFourBoard::winPosSlope (int collem){
	bool win = false;
	int j =0;
	while( j <5 && Board[j][collem] == '_')
	{
		
		j = j+1;
	}
	char wincoller = Board[j][collem];
	int numInRow=1;
	//add to numinrow for all in row up to right.
	if(collem != 6 && j !=0 && Board[j-1][collem+1]==wincoller){
		numInRow++;
		if(collem != 5 && j !=1 && Board[j-2][collem+2]==wincoller){
			numInRow++;
			if(collem != 4 && j !=2 && Board[j-3][collem+3]==wincoller){
				numInRow++;
			}
		}
	}
	// add to numinrow for all down to left.
	if(collem != 0 && j !=6 && Board[j+1][collem-1]==wincoller){
		numInRow++;
		if(collem != 1 && j !=5 && Board[j+2][collem-2]==wincoller){
			numInRow++;
			if(collem != 2 && j !=4 && Board[j+3][collem-3]==wincoller){
				numInRow++;
			}
		}
	}
	//cout <<"numInRow: " << numInRow << endl;
	if(numInRow >=4){
	
		win = true;
	}
	//cout <<"winPosSlope: " << win << endl;
return win;
}

/*
ifwon is a method that checks all win conditions. If any win condition is true it returns true.

Parameters:
collem-char to give to other methods
win-bool to return if won

Return:
bool to return tue if player has won and false if they havent. 
*/


bool ConnectFourBoard:: ifwon(int collem){
	bool win = false;
	//if any win condition is true 
	if(winvert(collem)|| winHorzont(collem)||winPosSlope(collem)||winNegSlope(collem))
	{
		win = true;
	}
	return win;

}



