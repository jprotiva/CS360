/*
J.D.Protiva
CS360 Spring2018
Assignment: 1
Programe Discription:
This prgrame will call connect Four board, and use it to play a game of connect four.At the end of the game it
will ask the user if they would like to play again or exit. 

*/



#include <iostream>
#include "ConnectFourBoard.h"
using namespace std;

/*
Main has a few varibale 
Board- The saved connectFourBoard were the game will be saved on.
win- A boolean that is false and set to true once someone has won.
full-An integer to help determin if the board is full or not
collem - An integer to pass what collem a player wants to play hes peace on,also to che win conditions
again- An integer to determin if they want to play again or not.
*/
int main() {

	ConnectFourBoard Board;
	
	bool win = false;
	int full = 0;
	int collem,again;
	bool currentPlayerRed = true;
	
	
	cout<<"\nWelcome to Connect Four\n1:NewGame\n2:Quit"<<endl;
	cin >> again;
	bool test = true;
	while(test)
	{
		if(cin.fail() || again < 1 || again >2)
		{
			cin.clear(); 
			cin.ignore();
			cout<<"thats not an option\n1:NewGame\n2:Quit"<<endl;
			cin >> again;
		}
		else
		{
			test =false;
		}
	}		
	//if they want to play again rest.
	if(again == 1)
	{
		Board.reset();
		full=0;
		win = false;
	}
	if(again ==2)
	{
		win = true;
	}
	
	//while no one has won and board is not full
	while(!win && full <=42)
	{
		//if full is even make it reds turn
		if(currentPlayerRed){
			//drop a peace
			Board.showBoard();
			cout<< "It is Reds Turn Pleas pick a Collem" << endl;
			
				cin >> collem;
			
					
			Board.drop(collem, 'R');
			
				//check if won
				if(Board.ifwon(collem))
				{
					Board.showBoard();
					cout<< "Congrate RedPlayer won!!!"<< endl;
					win = true;
				}
			
			currentPlayerRed = false;
			
		}
		//if full is odd make it blacks turn
		else{
			//drop a peace
			Board.showBoard();
			cout<< "It is Blacks Turn Pleas pick a Collem" << endl;
			cin >> collem;
			Board.drop(collem, 'B');
			
			//check if won
			if(Board.ifwon(collem))
			{
				Board.showBoard();
				cout<< "Congrate BlackPlayer won!!!"<<endl;
				win = true;
				
			}
			currentPlayerRed = true;
		}
		
		
		full++;
		//cout<< "full: "<< full << endl;
		//if board is full
		if(full == 42)
		{
			Board.showBoard();
			cout<<"Its a Tie" << endl;
			win = true;
		}
		//if the game is over
		if(win)
		{
			
			cout<<"\n1:NewGame\n2:Quit"<<endl;
			cin >> again;
			bool test = true;
			while(test)
			{
				if(cin.fail() || again < 1 || again >2)
				{
					cin.clear(); 
					cin.ignore();
					cout<<"thats not an option\n1:NewGame\n2:Quit"<<endl;
					cin >> again;
				}
				else
				{
					test =false;
				}
			}
			
			
			//if they want to play again rest.
			if(again == 1)
			{
				Board.reset();
				full=0;
				win = false;
			}
		}
	}
	
	return 0;
}
