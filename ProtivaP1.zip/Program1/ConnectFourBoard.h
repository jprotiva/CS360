/*
J.D.Protiva
CS360 Spring2018
Assignment: 1
Programe Discription:
This is the .h file for ConnectFourBoard It contains all the methods within the ConnectFourBoard class.
It also creats the Board the 2d array and only private globale varable of the ConnectFourBoard class. 

*/
#include <string>

class ConnectFourBoard
{
	//private methods 
	private:
	//Board creation
	char Board [6][7];
	
	bool winvert (int collem);

	bool winHorzont (int collem);

	bool winPosSlope (int collem);

	bool winNegSlope (int collem);
	
	//public methods
	public:
	ConnectFourBoard();

	void showBoard();
	
	void reset();

	void drop(int collem, char turn);

	bool ifwon(int collem);
	
};
