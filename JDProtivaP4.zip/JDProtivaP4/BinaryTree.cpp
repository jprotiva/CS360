/*      
	BinaryTree is a class that creates a Binary Search Tree (BST).
	This class uses a custome node class that will actually store the data.
	BinaryTree monipulates the nodes into the BST for faster searching.
	BinarTree provides a constructor,destructor,addNode, deleteNode, search, 
	cleanupTree and printTree methods for user of BinaryTree to use. 
	
	
	Programer: J.D.Protiva
	CS360 Spring 2019
	Last edited: 06/07/2019
	Assignment #4
*/

//all incudes needed in the .h it includes the Node class
#include "BinaryTree.h"
#include <iostream>
#include <sstream>  
#include <stdlib.h>
//std makes all the couts nicer along with adding a bunch of other suf I dont us much of
using namespace std;

//here are some global variables to help the search class latter
Node* newNode;
Node* searchFound;

//the constructer makes a null
BinaryTree::BinaryTree()
{
	root = NULL;
}

/*
the destructer deltes the gobale varibles in addition to deleteing and cleaning 
the memorie of the entire BST (minus the local nodes used in other methods).
the destructer only handles deletes if the root is null else it callse a clean up
method to recursivly delete everything. 

***NOT MY US OF cleanupTee(Node*) DOSE NOT NEED cleanupTree()***
*/
BinaryTree::~BinaryTree()
{
	cout << "\nDesctructing The Tree" << endl;
	
	//deleteing the public nodes
	newNode =NULL;
	delete newNode;
	searchFound =NULL;
	delete searchFound;
	
	//if the tree is empty
	if (root == NULL)
	{
		delete root;
	}
	//if the tree is full
	else
	{
		//recursivly delete everything
		cleanupTree(root);
	}
}

/*
cleanupTree is a method that is passed a node the recursivly deltes all nodes under 
that node in the BST. It dose the the a recursive triversal of the BST.
*/
void BinaryTree::cleanupTree(Node *leaf)
{
	//if there is a left go left recursivley
	if(leaf-> getLeft() != NULL)
	{
		cleanupTree(leaf -> getLeft());
	}
	//if there is a right gor right recursivley
	if(leaf-> getRight() != NULL)
	{
		cleanupTree(leaf -> getRight());
	}
	//if you can go any lower delete node
	delete leaf;
}

/*
addNode is a tree that adds a new value to the BST.
The first method anly handles if the root is null then callse a recursive private method to
help add the node in the correct spot. 
*/
void BinaryTree::addNode(int value)
{
	// if root is null set the new value as rootNode
	if(root == NULL)
	{
		root = new Node(value);
	}
	// if root is not NULL call recursive helper method
	else
	{
		addNode(value, root);
	}
}

/*
addNode is a private method that is passed a value and leaf. 
then the method recursivly triverses the BST until it finds a parent for the value
it was passed. then it adds the value to the BST.
*/
void BinaryTree::addNode(int value, Node *leaf)
{
	// this ferst section is only for a print statment these are variables needed
	string leftNode = "NULL";
	string rightNode = "NULL";
	stringstream ssL;
	stringstream ssR;
	
	// if the leaf dose have a left child it creats a string value of the child set to leftNode
	if(leaf->getLeft()!=NULL)
	{
		int tempLeftNode = leaf->getLeft()->getValue();
		ssL.clear();
		ssL << tempLeftNode;
		leftNode = ssL.str();
	}
	// if the leaf dose have a right child it creats a string value of the child set to rightNode
	if(leaf->getRight()!=NULL)
	{
		int tempRightNode = leaf->getRight()->getValue();
		ssR.clear();
		ssR << tempRightNode;
		rightNode = ssR.str();
	}
	
	// the print statment the print the right and left child of current leaf
	cout << "\tvisiting node,left,right:\t"<< leaf->getValue() << "," << leftNode << ","
	<< rightNode << endl;
	
	//cleaning up data
	ssL.clear();
	ssR.clear();
	
	//now to recursivley trivers the list.
	
	//value is greater or equal to leaf
	if(value >= leaf->getValue())
	{
		//if the is a right nod trivers right
		if(leaf->getRight() != NULL)
		{
			addNode(value, leaf->getRight());
		}
		//if there is no right make new value equal to the right
		else
		{
			leaf->setRight(new Node(value));
		}
	}
	//value is less then leaf
	else
	{
		// if there is a left trivers left
		if(leaf->getLeft() != NULL)
		{
			addNode(value, leaf->getLeft());
		}
		//if there is no left set value to left
		else
		{
			leaf->setLeft(new Node(value));
		}
	}
}

/*
the extrimly complex deleteNode method conceptuly only deletes a value from the BST
however you need to find pointers to all the data bellow the value and connect them to new parents. 
This is were the complexity comes in the ferst deleteNode method handls if the value we are passed
to delete is the root. if it is not the root then we call a helper method to recursivly look to 
delete the method.
*/

void BinaryTree::deleteNode(int value)
{
	cout << "\ntrying tp delet node with value: "<< value << endl;
	//if the tree is empty
	if(root == NULL )
	{
		cout << "\nnode with value: "<< value <<"dose not exist" << endl;
	}
	// if the tree is not empty
	else
	{
		// if value we are attempting to delete is root
		if(root-> getValue() == value)
		{
			// creat a node pointer to origanal/current root (OR)
			Node* placeHolder = root;
			
			//if the root has no children make BST empty
			if(root->getLeft() == NULL && root -> getRight() == NULL)
			{
				root = NULL;
			}
			
			// if root has a child make that child the new root 
			else if(root-> getLeft() != NULL && root -> getRight() == NULL)
			{
				root = root->getLeft();
			}
			else if(root-> getLeft() == NULL && root -> getRight() != NULL)
			{
				root = root->getRight();
			}
			
			//if the root has two kids
			else
			{
				
				// if left kid dos not have a right kid 
				if( root->getLeft()->getRight() == NULL)
				{
					// set the OR right child to OR left child
					root->getLeft()->setRight(root->getRight());
					root = root-> getLeft();
				}
				//if the OR left child has a right child
				else
				{
					
					// creat a temp node
					Node* temp = root-> getLeft();
					
					//trivers going right of the OR left child
					while(temp -> getRight() != NULL)
					{
						temp = temp-> getRight();
					}
					//set the OR left ferthest right Node to OR right child
					temp->setRight(root->getRight());
					
					// sets OR left child to new Node
					root = root->getLeft();
					
					// clean temp node
					temp = NULL;
					delete temp;
					
				}
			}
			
			// clean OR and place holder
			delete placeHolder;
			
			cout << "\ndeleted rootNode with value: "<< value << endl;
		}
		// if value is not equal to root
		else
		{
			// call recursive delete method
			deleteNode(value, root);
		}
	}
	
	
}
/*
deleteNode(value,node*) is a method the recursivly triverses the BST searching for value, if found deletes it from 
the BST, if not it dose nothing
*/
void BinaryTree::deleteNode(int value, Node* leaf)
{
	//creats local variables to aid method
	bool foundLNode = false;
	bool foundRNode = false;
	Node* parent;
	Node* leftChild;
	Node* rightChild;
	
	// value is less then leafs
	if(value < leaf->getValue())
	{
		//if there is no left to go value not in BST
		if( leaf->getLeft()==NULL)
		{
			cout << "\nnode with value: "<< value <<" dose not exist" << endl;
		}
		// if leafs left child is value
		else if( leaf->getLeft()->getValue() == value)
		{
			//set local variables
			foundLNode = true;
			parent = leaf;
			leftChild = leaf->getLeft()->getLeft();
			rightChild = leaf->getLeft()->getRight();
			
		}
		// leaf is not value and there is a left go left
		else
		{
			deleteNode(value,leaf->getLeft());
		}
		
	}
	// if value is greater then leaf value
	else
	{
		// if there is no rgiht value not in BST
		if(leaf-> getRight() == NULL)
		{
			cout << "\nnode with value: "<< value <<" dose not exist" << endl;
		}
		// if leafs right child value is equal to value 
		else if( leaf->getRight()->getValue() == value)
		{
			// set local variables
			foundRNode = true;
			parent = leaf;
			leftChild = leaf->getRight()->getLeft();
			rightChild = leaf->getRight()->getRight();
			
		}
		// if there is a right and its not value trivers right
		else
		{
			deleteNode(value, leaf->getRight());
		}
	}
	
	//if local variabls were set so the value is a left child
	if(foundLNode)
	{
		// place holder on value node
		Node* placeHolder = parent -> getLeft();
		
		// if value node had no children
		if(leftChild == NULL && rightChild == NULL)
		{
			//set parenst left to null
			parent -> setLeft(NULL);
			
		}
		// if value node had one child set parents left to that child
		else if(leftChild != NULL && rightChild == NULL)
		{
			parent -> setLeft(leftChild);
		}
		else if(leftChild == NULL && rightChild != NULL)
		{
			parent -> setLeft(rightChild);
		}
		
		// if value node had two childre 
		else
		{
			// make temp node
			Node* temp = leftChild;
			
			// trivers left then as right as can go
			while(temp->getRight() != NULL)
			{
				temp = temp->getRight();
			}
			//set valuess right child to left right as far as you can go
			temp -> setRight(rightChild);
			// chang parents left child to values left child
			parent -> setLeft(leftChild);
			
			//clean temp node
			temp = NULL;
			delete temp;
			
		}
		
		// clean value node and placeholder
		delete placeHolder;
		cout << "\ndeleted Node with value: "<< value << endl;
		
	}
	// if local variables were set making variable a right child
	else if(foundRNode)
	{
		// set place holder for value node
		Node* placeHolder = parent -> getRight();
		
		// if value node has no childre set parents right child to NULL
		if(leftChild == NULL && rightChild == NULL)
		{
			
			parent -> setRight(NULL);
		}
		// if value node has one child set parents right child to that child
		else if(leftChild != NULL && rightChild == NULL)
		{
			parent -> setRight(leftChild);
		}
		else if(leftChild == NULL && rightChild != NULL)
		{
			parent -> setRight(rightChild);
		}
		// if value node has two children
		else
		{
			// creat temp node
			Node* temp = leftChild;
			
			// trivers left once then right as far as can go
			while(temp->getRight() != NULL)
			{
				temp = temp->getRight();
			}
			// set right child to left right as far node
			temp -> setRight(rightChild);
			// set parents right to value nodes left child 
			parent -> setRight(leftChild);
			
			// clean up temp node
			temp = NULL;
			delete temp;
		}
		
		// clean up value node and local Node placeholder
		delete placeHolder;
		cout << "\ndeleted Node with value: "<< value << endl;
	}
	// clean up local helper nodes
	parent = NULL;
	leftChild = NULL;
	rightChild = NULL;
	
	delete parent;
	delete leftChild;
	delete rightChild;
}


/*
search is a method that is passed a value then returns the node that equals that value if found.
if not returns NULL. it calls a helper search method to recursivly trivers the BST looking for value.
if value is found the set gobal variables to equal it. The need for global variables is you cant delete
and clean the nodes that are being returned unless they are global.
*/
Node* BinaryTree::search(int value)
{
	cout << "\nBinaryTree::searching for "<< value << endl;
	
	// if BST is not empty
	if(root != NULL)
	{
		// call recursive search
		newNode = search(value,root);
		// seting global return value equal to globale search value
		newNode = searchFound;
		
	}
	
	// if recursive search found value 
	if(newNode != NULL && newNode->getValue() == value)
	{
		
		cout << "found it!\n" << endl;
	}
	// if recursive search did not find value
	else
	{
		cout << "value not found \n" << endl;
		// if value not found set newNode to null
		newNode = NULL;
	} 
	return newNode;
}

/*
search(value,node*) recursivly looks for value if found sets a globale variable node
to that node with value if not found dose nothing.
*/
Node* BinaryTree::search(int value, Node *leaf)
{
	
	cout << "\tBinaryTree::search(n,val):"<< leaf->getValue() << "," << value << endl;
	// creats temp node
	Node* newInSearchNode;
	
	// if value is less then leaf and there is a left child 
	if(value < leaf->getValue() && leaf->getLeft() != NULL)
	{
		// recursivly go into the left child
		newInSearchNode = search(value, leaf->getLeft());
	}
	// if value is more then leaf value and there is a right child 
	if(value > leaf->getValue() && leaf->getRight() != NULL)
	{
		// recursivly go into the right child
		newInSearchNode = search(value, leaf->getRight());
	}
	// if leaf is equal to value
	if(value == leaf->getValue())
	{
		// set global variable to leaf
		searchFound = leaf;
	}
	
	//cleanlocal node
	newInSearchNode = NULL;
	delete newInSearchNode;
	
	//return dosnt matter 
	return leaf;	
}

/*
printTree is passed a boolean variable to determen if it will print a desending or ascending tree.
then if the tree is not null in prints the tree acordingly. if the tree is null it prints a message 
then exits. it uses two helper method the triverses recursivly to print BST. one for ascending, one for
descending.
*/
void BinaryTree::printTree(bool ascending)
{
	// if BST is empty 
	if(root == NULL)
	{
		// prints message then exits 
		cout << "\ndata.txt file was empty!  exiting." << endl;
		exit (EXIT_FAILURE);
	}
	// if BST is not empty
	else
	{
		// if ascending is true
		if(ascending)
		{
			cout << "\nPrinting Tree in ascending order" << endl;
			// calls ascending helper method 
			printTreeAscending(root);
		}
		// if ascending is false
		else
		{
			cout << "\nPrinting Tree in descending order" << endl;
			// call descending helper method
			printTreeDescending(root);
		}
		
		cout << "done printing tree. " << endl;
	
	}
}

/*
printTreeAscending is a helper method recursivly traves left then 
prints then travles right.
*/
void BinaryTree::printTreeAscending(Node *leaf)
{
	if(leaf->getLeft() != NULL)
	{
		printTreeAscending(leaf->getLeft());
	}
	cout << "value: "<< leaf->getValue() << endl;	
	if(leaf->getRight() != NULL)
	{
		printTreeAscending(leaf->getRight());
	}
	
}
/*
printTreeDescending is a helper method recursivly traves right then 
prints then travles left.
*/
void BinaryTree::printTreeDescending(Node *leaf)
{
	if(leaf->getRight() != NULL)
	{
		printTreeDescending(leaf->getRight());
	}
	
	cout << "value: "<< leaf->getValue() << endl;	
	
	if(leaf->getLeft() != NULL)
	{
		printTreeDescending(leaf->getLeft());
	}
}





