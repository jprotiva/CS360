/*      
	Node is a class that has a value that is an int it stores 
	a right and left chilld which point to other Nodes. you must set value 
	 creation,you can get value set Left and right children and get left 
	and right chldren. the destructer changes the children to NULL
	befor deleting them
	
	Programer: J.D.Protiva
	CS360 Spring 2019
	Last edited: 06/07/2019
	Assignment #4
*/

// includes 
#include "Node.h"
#include <iostream>

using namespace std;

	// constructer value cant be Null
	Node::Node(int val)
	{
		value = val;
		right = NULL;
		left = NULL;
	}
       	// desctructer
        Node::~Node()
        {
        	cout << "cleaning Node: "<< value << endl;
        	right = NULL;
        	left = NULL;
        	delete right;
        	delete left;
        }
       	//getValue returns value 
        int  Node::getValue()
        {
        	return value;	
        }
        //getLeft returns left child
        Node*  Node::getLeft()
        {
        	
        	return left;
        }
        // getRight returns right child 
        Node*  Node::getRight()
        {
        	return right;
        }
        // setRight points right child to a passed node 
        void  Node::setRight(Node* n)
        {
        	right = n;
        }
        // set Left point left child to a passed node
        void  Node::setLeft(Node* n)
        {
        	left = n;
        }
