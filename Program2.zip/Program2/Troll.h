#ifndef	Troll_h
#define Troll_h

#include "Enemy.h"

class Troll : public Enemy {
	friend class Enemy;
	
	private:
	int tempX;
	int tempY;
	int damage;
	int damageAttempt;
	
	
	
	public:
	Troll(int,int,int,int,int);
	
	void update();
	void attack();
	void injure(int);
	void print() const;
	
};

#endif
