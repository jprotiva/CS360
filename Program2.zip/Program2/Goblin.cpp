# include "Goblin.h"
#include <iostream>
#include <cstdlib>
using namespace std;


Goblin::Goblin (int MaxHealth,int Strength,int Constitution,int StartingXLocation,int StartingYLocation)
 : Enemy( MaxHealth,Strength,Constitution,StartingXLocation,StartingYLocation)
{
	

	Id =0;
	
	CurrentHealth=MaxHealth;
	currentXPosition=StartingXLocation;
	currentYPosition=StartingYLocation;
	print();
}

void Goblin::update()
{
	
	tempX=(rand()%6)-3;
	currentXPosition =currentXPosition + tempX;
	
	 tempY=tempX=(rand()%4)-2;;
	currentYPosition = currentYPosition + tempY;
}

void Goblin::attack()
{
	damage = Strength + (rand()%4)+1;
	
	cout<< "goblin " << Id << "Attacks random passerby for " << damage << " damage"<< endl;
}

void Goblin::injure(int lucky)
{
	damageAttempt = rand()%10 ;
	damage = damageAttempt - (Constitution *.5);
	
	if(damage <= 0)
	{
		cout << "The Passerby tries to attack goblin " << Id << " Its not very effective..." << endl;
	}
	else
	{
		CurrentHealth = CurrentHealth - damage;
		cout << "The Passerby attacks goblin " << Id << " for " << damageAttempt <<endl;
		if(CurrentHealth >0)
		{
			cout << "goblin " << Id << " takes " << damage << "hp = "<< CurrentHealth <<endl;
		}
		else
		{
			Alive = false;
			cout << "goblin " << Id << " has been slain!" << endl;
		}
	}
}

void Goblin::print() const
{
	cout << "goblin " << Id << " @ (" << currentXPosition << ", " << currentYPosition << ") hp = " << CurrentHealth << endl;
}





