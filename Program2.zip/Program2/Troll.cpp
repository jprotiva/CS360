# include "Troll.h"
#include <iostream>
#include <cstdlib>

using namespace std;


Troll::Troll (int MaxHealth,int Strength,int Constitution,int StartingXLocation,int StartingYLocation)
 : Enemy( MaxHealth,Strength,Constitution,StartingXLocation,StartingYLocation)
{
	

	Id =1;
	
	CurrentHealth=MaxHealth;
	currentXPosition=StartingXLocation;
	currentYPosition=StartingYLocation;
	print();
}

void Troll::update()
{
	
	tempX =rand()%1; //just used as a temp int 
	if(rand ==0){
	
		tempX=(rand()%3)+7;
	}
	
	else
	{
		tempX=(rand()%3)-10;
	}
	currentXPosition =currentXPosition + tempX;
	
	int RecoveredHealth = MaxHealth - CurrentHealth;
	
	if(RecoveredHealth> Constitution)
	{
		RecoveredHealth = Constitution;
	}
	
	CurrentHealth = CurrentHealth + Constitution;
	
	if(CurrentHealth > MaxHealth)
	{
		CurrentHealth = MaxHealth;
	} 
	
	cout<< "Troll " << Id << " Heald " << RecoveredHealth <<  " Troll " << Id<< " now has "<< CurrentHealth << endl;
	
	/* tempY=tempX=(rand()%4)-2;;
	currentYPosition = currentYPosition + tempY;
	*/
}

void Troll::attack() 
{
	damage = Strength + (rand()%8)+1;
	cout<< "Troll " << Id << "Attacks random passerby for " << damage << " damage"<< endl;
}

void Troll::injure(int lucky)
{
	damageAttempt = rand()%10 ;
	damage = damageAttempt - (Constitution *.5);
	
	if(damage <= 0)
	{
		cout << "The Passerby tries to attack Troll " << Id << " Its not very effective..." << endl;
	}
	else
	{
		CurrentHealth = CurrentHealth - damage;
		
		if(CurrentHealth >0)
		{
			cout << "Troll " << Id << " takes " << damage << "hp = "<< CurrentHealth <<endl;
		}
		else
		{
			Alive = false;
			cout << "Troll " << Id << " has been slain!" << endl;
		}
	}
}

void Troll::print() const
{
	cout << "Troll " << Id << " @ (" << currentXPosition << ", " << currentYPosition << ") hp = " << CurrentHealth << endl;
}





