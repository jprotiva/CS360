#include "Orc.h"
#include <iostream>
#include <cstdlib>
using namespace std;


Orc::Orc (int MaxHealth,int Strength,int Constitution,int StartingXLocation,int StartingYLocation)
 : Enemy( MaxHealth,Strength,Constitution,StartingXLocation,StartingYLocation)
{
	

	Id =2;
	
	CurrentHealth=MaxHealth;
	currentXPosition=StartingXLocation;
	currentYPosition=StartingYLocation;
	print();
}


void Orc::update()
{
	
	tempX=(rand()%11)-5;
	currentXPosition =currentXPosition + tempX;
	currentYPosition = currentYPosition + tempX;
}

void Orc::attack() 
{
	damage = Strength + (rand()%6)+1;
	
	cout<< "Orc " << Id << "Attacks random passerby for " << damage << " damage"<< endl;
}

void Orc::injure(int lucky)
{
	damageAttempt = rand()%10 ;
	damage = damageAttempt;
	
	if(damage <= 0)
	{
		cout << "The Passerby tries to attack Orc " << Id << " Its not very effective..." << endl;
	}
	else
	{
		CurrentHealth = CurrentHealth - damage;
		
		if(CurrentHealth >0)
		{
			cout << "Orc " << Id << " takes " << damage << "hp = "<< CurrentHealth <<endl;
		}
		else
		{
			Alive = false;
			cout << "Orc " << Id << " has been slain!" << endl;
		}
	}
}

void Orc::print() const
{
	cout << "Orc " << Id << " @ (" << currentXPosition << ", " << currentYPosition << ") hp = " << CurrentHealth << endl;
}





