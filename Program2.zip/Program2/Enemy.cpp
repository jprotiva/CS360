# include "Enemy.h"
#include <string>
#include <iostream>
using namespace std;


Enemy::Enemy(int MaxH, int Str,int Con,int x,int y)
{	


		
	MaxHealth=MaxH;
	Strength =Str;
	Constitution=Con;
	StartingXLocation=x;
	StartingYLocation=y;
	Alive = true;
}

bool Enemy::isAlive()
{
	return Alive;
}
