#ifndef Goblin_h
#define Goblin_h

#include "Enemy.h"

class Goblin : public Enemy {
	friend class Enemy;
	
	private:
	int tempX;
	int tempY;
	int damage;
	int damageAttempt;
	
	
	
	public:
	Goblin(int,int,int,int,int);
	
	void update();
	void attack();
	void injure(int);
	void print() const;
	
};

#endif
