
#ifndef Enemy_h
#define Enemy_h
#include <string>

class Enemy{
	protected:
	
	int Id;
	int MaxHealth;
	int CurrentHealth;
	int currentXPosition;
	int currentYPosition;
	int Strength;
	int Constitution;
	int StartingXLocation;
	int StartingYLocation;
	bool Alive;
	
	public:
	
	Enemy(int, int, int, int, int);
	bool isAlive();
	virtual void update() =0;
	virtual void attack() =0;
	virtual void injure(int) =0;
	virtual void print() const =0;
	
};

#endif
