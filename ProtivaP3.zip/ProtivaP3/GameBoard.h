/*
	Programer: J.D.Protiva
	CS360 Spring 2019
	Assignment #3
	
	Description:
	GameBoard.h is a .h file for gameBoard.cpp it crates a double pointer to a char grid 
	and two int variable representing the grides siz. also declrease the methodes that GameBoard
	will use.
*/
#ifndef GameBoard_H
#define GameBoard_H
#include "Enemy.h"

class GameBoard 
{
	private:
		char **grid;
		int Boardx;
		int Boardy;
	public:
		GameBoard(int,int);
		 void printBoard();
		 void resetBoard();
		 void addGamePiece(Enemy*);
};

#endif
