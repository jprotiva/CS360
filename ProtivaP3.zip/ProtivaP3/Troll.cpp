/*
	Programer: J.D.Protiva
	CS360 Spring 2019
	Assignment #3
	
	Description:
	Toll.cpp is the conter parte to the api Troll.h it includes a constructer and. 
	update changes the position of Troll and heals the troll. 
	Attack which prints howmuch damage the Troll dose that turn.
	injure which calculates the amount of damage Troll takes. 
	print wich prints the Trolls id, location, and health.
*/
# include "Troll.h"
#include <iostream>
#include <cstdlib>

using namespace std;

/*constructor sets maxHealth to health and print()
Parameters: 	int Health: represents the Troll health
		int Strength: represents the Troll Strength
		int Constitution: represents the Troll Constitution
		int StartingXLocation: represents the Troll Starting X Location
		int StartingYLocation: represents the Troll Starting Y Location
Return: none
 */
Troll::Troll (int MaxHealth,int Strength,int Constitution,int StartingXLocation,int StartingYLocation)
 : Enemy( MaxHealth,Strength,Constitution,StartingXLocation,StartingYLocation)
{
	//sets maxHealth
	maxHealth=health;
	print();
}

/*
update changes the position of the troll. Troll's only trives the x axes and travel from 7-10 units of distance in eathr positiv
or negative directions. In additionto changing the position of the troll update also heals the troll for the trolls constitiution
value unless the troll is heald to max health or dead.
Parameters: none
Return: none
*/ 
void Troll::update()
{
	if (alive)
	{
		int tempX =rand()%2; //just used as a temp int 
		if(tempX ==0){//moving positivly
			
			tempX=(rand()%3)+7;
		}

		else//moving negativly 
		{
			tempX=(rand()%3)-10;
		}
		xPosition =xPosition + tempX;
		
		//the amound needed to be recoverd 
		int RecoveredHealth = maxHealth - health;
		
		// sets recovered health to con if the amount needed is greater then con
		if(RecoveredHealth> con)
		{
			RecoveredHealth = con;
		}
		
		// recover the amount apropret
		health = health + RecoveredHealth;
		
		//if there was a messtake and over healing occurse 
		if(health > maxHealth)
		{
			health = maxHealth;
		} 
		
		//prints amound heald 
		cout<< "Troll " << id << " Heald " << RecoveredHealth <<  " Troll " << id<< " now has "<< health << endl;
	}
}

/*prints the amound of damage goblin dose str + d8 roll.
Parameters: none
Return: none
*/ 
void Troll::attack() const
{	//sets damage
	int damage = str + (rand()%8)+1;
	
	cout<< "Troll " << id << " Attacks random passerby for " << damage << " damage"<< endl;
}


/*
receves an int then determans how much damage Troll takes after constitution 
is subtracted from the int given. if Troll dies sets alive to false and prints.
if the int given is less then the constitution of goblin then goblin takes no damage,
Parameters: int lucky: the amount the Passerby by will try to attck Troll for
Return: none
*/
void Troll::injure(int lucky)
{
	//calculating potental damage
	int damage = lucky - (con *1.5);
	
	//if not effective
	if(damage <= 0)
	{
		cout << "The Passerby tries to attack Troll " << id << " Its not very effective..." << endl;
	}
	else
	{	//changing health
		health = health - damage;
		
		//if troll survives 
		if(health >0)
		{
			cout << "Troll " << id << " takes " << damage << "hp = "<< health <<endl;
		}
		else
		{
			alive = false;
			cout << "Troll " << id << " has been slain!" << endl;
		}
	}
}

/*prints Troll's id postion and health
Parameters: none
Return: none
*/ 
void Troll::print() const 
{
	cout << "Troll " << id << " @ (" << xPosition << ", " << yPosition << ") hp = " << health << endl;
}

/*returns t if dead T if alive 
Parameters: none
Return: char Orc: reprensents Orc and wther it is alive or not
*/
const char Troll::getDisplayChar() const
{
	char Troll = 't';
	if(alive)
	{
		Troll = 'T';
	}
	return Troll;
}



