/*
	Programer: J.D.Protiva
	CS360 Spring 2019
	Assignment #3
	
	Description:
	GameBoard has a constructor and a few diffrent methodes reset to reset all vales of the board to 
	make the board empty.print board to print the board. addGamePeace to add any monster on the board 
	to its appropreat position.
*/
#include "GameBoard.h"
#include <string>
#include <iostream>
#include <cstdlib>

using namespace std;

/*the constructor of the board
Parameters:int x: represents the width of the board 
		   int y: represents the hight of the board
Return: nune 
*/
GameBoard::GameBoard(int x,int y)
{
	
	//crating grid size
	Boardx=x*2+1;
	Boardy=y*2+1;
	
	//crating grid 
	grid=new char*[Boardy];
	
	for (int i = 0; i < Boardx; i++)
	{
		grid [i] = new char[Boardy];
	}
	
	//seting grid to empty
	resetBoard();
}

/*triverses the grid reseting it 
Parameters: none
Return: none
*/
void GameBoard::resetBoard()
{
	//creates the grid full of char .'s
	for(int i=0; i<(Boardy);i++)
	{
		for(int j=0; j<(Boardx);j++)
		{
			grid[j][i] = '.';
		}
	}
	//sets middle collem to |'s
	for(int i=0; i<(Boardy);i++)
	{
		grid[((Boardx-1)/2)+1][i] = '|';
	}
	//sets middle row to _'s
	for(int j=0; j<(Boardx);j++)
	{
		grid[j][((Boardy-1)/2)+1] = '_';
	}
}

/*prints the board 
Parameters: none
Return: none
*/
void GameBoard::printBoard()
{
	//crating printBoard
	string printBoard = "";
	//triverses grid adding to printBoard at each location
	for(int i=0; i<(Boardy);i++)
	{
		for(int j=0; j<(Boardx);j++)
		{
			printBoard = printBoard + grid[j][i];
		}
		printBoard = printBoard + "\n";
	}
	//printing print board 
	cout<< printBoard << endl;
}


/*
adds a game peace to the grid. if the peace is off gride then it adds
to the clossest point on the grid. if the location entered is already cupied 
it adds the peace randomly within 2 places of the grid. 

Parameters: Enemy* a pointer to an Enemy to be added to the board.
Return: none
*/
void GameBoard::addGamePiece(Enemy* GamePiece)
{
	//getting location of x and y from enemy
	int tempX = GamePiece->getX();
	int tempY = GamePiece->getY();
	
	//setting x and y to middle
	int halfx = ((Boardx-1)/2)+1;
	int halfy = ((Boardy-1)/2)+1;
	//setting x and y to game peace location in double array
	int x = halfx + tempX;
	int y = halfy - tempY;//negative couse number needs to go up in game board not down
	
	//if off board put it on edge of board 
	
	if(x > Boardx-1)
	{
		x = Boardx-1;
	}
	
	if(y > Boardy-1)
	{
		y = Boardy-1;
	}
	
	if(x < 0 )
	{
		x = 0;
	}
	
	if(y < 0)
	{
		y = 0;
	}
	
	// if peace ocupys location put randomly up to two squars away
	
	while(grid[x][y]!= '.' && grid[x][y]!= '_' && grid[x][y]!= '|')
	{
		int random = (rand()%5)-2;
		x = x + random;
		y = y + random;
		
		if(x > Boardx-1)
		{
			x = Boardx-1;
		}
		if(y > Boardy-1)
		{
			y = Boardy-1;
		}
		
		if(x < 0 )
		{
			x = 0;
		}
	
		if(y < 0)
		{
			y = 0;
		}
		
	
		GamePiece->setX(-(halfx -x));
		GamePiece->setY(halfy -y);
		
		cout << "--There was a Colision Enamies new location is--" << endl;
		GamePiece-> print(); 	
	}
	
	//placeing game peace 
	
	grid[x][y] = GamePiece->getDisplayChar();
	
	
	
	
}




