/*
	Programer: J.D.Protiva
	CS360 Spring 2019
	Assignment #3
	
	Description:
	Enemy.cpp is a object that has a Enemy.h api Enemy has a constructor that is passed five 
	intergers and the sets those integers to the appropreate object dat along with setting alive to true
	and generating a id number for the new Enemy Enemy also has a number a get methods that return the
	respected data.
	
	
*/
# include "Enemy.h"
#include <string>
#include <iostream>
using namespace std;

//constructor
Enemy::Enemy(int MaxH, int Str,int Con,int x,int y)
{	
	static int idGenerator;
	idGenerator++;
	id =idGenerator;
	
	health=MaxH;
	//CurrentHealth=MaxHealth;
	str =Str;
	con=Con;
	xPosition=x;
	yPosition=y;
	alive = true;
}
//is alive returns avlives boolean value
bool Enemy::isAlive() const
{
	return alive;
}

//get any info that you would want
//returns that infos int value 
int Enemy::getId() const
{
	return id;
}

int Enemy::getHealth() const
{
	return health;
}

int Enemy::getStr() const
{
	return str;
}

int Enemy::getCon() const
{
	return con;
}

int Enemy::getX() const
{
	return xPosition;
}

int Enemy::getY() const
{
	return yPosition;
}

void Enemy::setX(int x) 
{
	xPosition=x;
}

void Enemy::setY(int y) 
{
	yPosition=y;
}







