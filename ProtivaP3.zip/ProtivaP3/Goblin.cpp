
/*
	Programer: J.D.Protiva
	CS360 Spring 2019
	Assignment #3
	
	Description:
	Goblin.cpp is the conter parte to the api Goblin.h it includes a constructer and. 
	update changes the position of goblin. 
	Attack which prints howmuch damage the goblin dose that turn.
	injure which calculates the amount of damage gablin takes. 
	print wich prints the goblins in, location, and health.
*/

# include "Goblin.h"
#include <iostream>
#include <cstdlib>
using namespace std;

/*constructor allso prints goblin at start. Goblins stats have already been declared in 
enemys decleration 
Parameters: 	int Health: represents the Goblines health
		int Strength: represents the Goblines Strength
		int Constitution: represents the Goblines Constitution
		int StartingXLocation: represents the Goblines Starting X Location
		int StartingYLocation: represents the Goblines Starting Y Location
Return: none
*/
Goblin::Goblin (int Health,int Strength,int Constitution,int StartingXLocation,int StartingYLocation)
 : Enemy( Health,Strength,Constitution,StartingXLocation,StartingYLocation)
{
	print();
}

/*update cahnges the position x any were up to 3 movement y anywere up to 2
Parameters: none
Return: none
*/
void Goblin::update()
{
	xPosition =xPosition+ (rand()%6)-3;
	
	
	yPosition = yPosition+ (rand()%4)-2;
	
}

/*prints the amound of damage goblin dose str + d4 
Parameters: none
Return: none
*/
void Goblin::attack() const
{ 
	
	cout<< "Goblin " << id << " Attacks random passerby for " << str + (rand()%4)+1 << " damage"<< endl;
}

/*
receves an int then determans how much damage goblen takes after half of constitution 
is subtracted from the int given. if goblin dies sets alive to false and prints.
if the int given is less the nhalf the constitution of goblin then goblin takes no damage,
Parameters: int lucky: the amount the Passerby by will try to attck Goblin for
Return: none
*/
void Goblin::injure(int lucky)
{
 	//calculating possible damage
	int damage =lucky - (con *.5);
	
	//if damage is not effective
	if(damage <= 0)
	{
		cout << "The Passerby tries to attack goblin " << id << " Its not very effective..." << endl;
	}
	
	
	else
	{	//change health
		health = health - damage;
		
		//if goblin lives 
		if(health >0)
		{
			cout << "Goblin " << id << " takes " << damage << "hp = "<< health <<endl;
		}
		else
		{
			alive = false;
			cout << "Goblin " << id << " has been slain!" << endl;
		}
	}
}

/*prints goblins id postion and health
Parameters: none
Return: none
*/

void Goblin::print()const
{
	cout << "Goblin " << id << " @ (" << xPosition << ", " << yPosition << ") hp = " << health << endl;
}

/*returns g if dead G if alive 
Parameters: none
Return: char goblin: reprensents goblin and wther it is alive or not
*/
const char Goblin::getDisplayChar() const
{
	char goblin = 'g';
	if(alive)
	{
		goblin = 'G';
	}
	return goblin;
}




