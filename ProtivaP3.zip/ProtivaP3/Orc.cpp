/*
	Programer: J.D.Protiva
	CS360 Spring 2019
	Assignment #3
	
	Description:
	Orc.cpp is the conter parte to the api Orc.h it includes a constructer and. 
	update changes the position of Orc. 
	Attack which prints howmuch damage the Orc dose that turn.
	injure which calculates the amount of damage Orc takes. 
	print wich prints the Orc id, location, and health.
*/
#include "Orc.h"
#include <iostream>
#include <cstdlib>
using namespace std;

/*constructor allso prints Orc at start. Orc stats have already been declared in 
enemys decleration
 Parameters: 	int Health: represents the Orc health
		int Strength: represents the Orc Strength
		int Constitution: represents the Orc Constitution
		int StartingXLocation: represents the Orc Starting X Location
		int StartingYLocation: represents the Orc Starting Y Location
Return: none
 */
 Orc::Orc (int Health,int Strength,int Constitution,int StartingXLocation,int StartingYLocation)
 : Enemy( Health,Strength,Constitution,StartingXLocation,StartingYLocation)
{
	print();
}
/*update cahnges the position x any were up to 3 traveling diaganaly
Parameters: none
Return: none
*/
void Orc::update()
{
	
	int tempX=(rand()%6)-3;
	
	xPosition = xPosition + tempX;
	yPosition = yPosition + tempX;
	
}

/*prints the amound of damage goblin dose str + d6 roll.
Parameters: none
Return: none
*/
void Orc::attack() const
{
	int damage = str + (rand()%6)+1;
	
	cout<< "Orc " << id << " Attacks random passerby for " << damage << " damage"<< endl;
}
/*
receves an int then determans how much damage Orc takes after constitution 
is subtracted from the int given. if Orc dies sets alive to false and prints.
if the int given is less then the constitution of Orc then Orc takes no damage,
Parameters: int lucky: the amount the Passerby by will try to attck Orc for
Return: none
*/
void Orc::injure(int lucky)
{
	//calculating potental damage
	int damage = lucky-con ;
	
	//if not effective
	if(damage <= 0)
	{
		cout << "The Passerby tries to attack Orc " << id << " Its not very effective..." << endl;
	}
	else
	{	//changing health
		health = health - damage;
		
		//if goblin lives
		if(health >0)
		{
			cout << "Orc " << id << " takes " << damage << "hp = "<< health <<endl;
		}
		else
		{
			alive = false;
			cout << "Orc " << id << " has been slain!" << endl;
		}
	}
}

/*prints Orc's id postion and health
Parameters: none
Return: none
*/
void Orc::print() const
{
	cout << "Orc " << id << " @ (" << xPosition << ", " << yPosition << ") hp = " << health << endl;
}

/*returns o if dead O if alive 
Parameters: none
Return: char Orc: reprensents Orc and wther it is alive or not
*/
const char Orc::getDisplayChar()const
{
	char Orc = 'o';
	if(alive)
	{
		Orc = 'O';
	}
	return Orc;
}




